#!/usr/bin/env bash
java -XstartOnFirstThread -jar ghh.jar
